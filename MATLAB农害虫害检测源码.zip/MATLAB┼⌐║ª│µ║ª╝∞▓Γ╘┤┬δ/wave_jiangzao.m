function [h s v] = wave_jiangzao(A)
% ��С������ͼ����

[h0,s0,v0] = rgb2hsv(A);
[thr,sorh,keepapp] = ddencmp('den','wv',h0);
xd = wdencmp('gbl',h0,'sym4',2,thr,sorh,keepapp);
h = xd;
clear xd; clear thr; clear sorh; clear keepapp; clear h0; 
[thr,sorh,keepapp] = ddencmp('den','wv',s0);
xd = wdencmp('gbl',s0,'sym4',2,thr,sorh,keepapp);
s = xd;
clear xd; clear thr; clear sorh; clear keepapp; clear s0;
[thr,sorh,keepapp] = ddencmp('den','wv',v0);
xd = wdencmp('gbl',v0,'sym4',2,thr,sorh,keepapp);
v = xd;
clear xd; clear thr; clear sorh; clear keepapp; clear v0;
